# Free Render Setup

This version explicitly requests a Free Render Web Service and Free Render Postgres database.

Important limitations: the web service can sleep after 15 minutes without traffic, and Free Render Postgres expires after 30 days. This is for demo/testing only and should not be used for real PHI.

Upload `render.yaml` to the root of your GitHub repository, then retry the Render Blueprint.
